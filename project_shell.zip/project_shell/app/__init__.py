"""FastAPI student agent shell."""
